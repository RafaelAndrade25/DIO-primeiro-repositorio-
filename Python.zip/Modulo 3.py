'''
Ex 1 ----- print('Ola, mundo!')
__________________________________________________
Ex 2
nome = input('Qual o seu nome?')
print('Ola', nome, 'Seja bem vindo(a)')

-----O print tambem pode ser escrito como:
print('E um prazer te conhecer, {}!'.format(nome))
__________________________________________________
'''
